<div class="container">
    <h1>
       <a style="color: #55200C;" href="index.php">
        Devote
       </a> 
    </h1>
</div>

<!-- put the clock and location here please and thank you!-->